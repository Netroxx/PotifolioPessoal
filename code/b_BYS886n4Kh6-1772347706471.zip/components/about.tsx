"use client"

import { useState } from "react"

const content = {
  pt: {
    title: "Sobre Mim",
    paragraphs: [
      "Sou um desenvolvedor Full Stack apaixonado por criar experiências digitais que combinam design funcional com engenharia sólida. Meu trabalho favorito está na interseção entre design e desenvolvimento, criando soluções que não apenas funcionam bem, mas são construídas com performance e usabilidade em mente.",
      "Tenho experiência com diversas tecnologias modernas, incluindo React, Next.js, TypeScript, Node.js, Python e bancos de dados relacionais e não-relacionais. Gosto de aprender continuamente e acompanhar as melhores práticas do mercado.",
      "Quando não estou programando, gosto de contribuir com projetos open source, participar de eventos da comunidade tech e explorar novas tecnologias e ferramentas.",
    ],
    skills: [
      "JavaScript / TypeScript",
      "React / Next.js",
      "Node.js",
      "Python",
      "PostgreSQL / MongoDB",
      "Git / GitHub",
      "Docker",
      "APIs REST",
    ],
    skillsTitle: "Tecnologias",
  },
  en: {
    title: "About Me",
    paragraphs: [
      "I'm a Full Stack developer passionate about building digital experiences that blend thoughtful design with robust engineering. My favorite work lies at the intersection of design and development, creating solutions that not only look great but are meticulously built for performance and usability.",
      "I have experience with several modern technologies, including React, Next.js, TypeScript, Node.js, Python, and both relational and non-relational databases. I enjoy continuous learning and keeping up with industry best practices.",
      "When I'm not coding, I like contributing to open source projects, attending tech community events, and exploring new technologies and tools.",
    ],
    skills: [
      "JavaScript / TypeScript",
      "React / Next.js",
      "Node.js",
      "Python",
      "PostgreSQL / MongoDB",
      "Git / GitHub",
      "Docker",
      "REST APIs",
    ],
    skillsTitle: "Technologies",
  },
}

export function About() {
  const [lang, setLang] = useState<"pt" | "en">("pt")
  const t = content[lang]

  return (
    <section id="sobre" className="px-6 py-24">
      <div className="mx-auto max-w-4xl">
        <div className="mb-12 flex items-center gap-4">
          <h2 className="text-2xl font-bold text-foreground md:text-3xl">
            {t.title}
          </h2>
          <div className="h-px flex-1 bg-border" />
          <div className="flex gap-2">
            <button
              onClick={() => setLang("pt")}
              className={`rounded-md px-3 py-1 font-mono text-xs transition-all ${
                lang === "pt"
                  ? "bg-primary text-primary-foreground"
                  : "border border-border text-muted-foreground hover:text-foreground"
              }`}
              aria-label="Português"
            >
              PT
            </button>
            <button
              onClick={() => setLang("en")}
              className={`rounded-md px-3 py-1 font-mono text-xs transition-all ${
                lang === "en"
                  ? "bg-primary text-primary-foreground"
                  : "border border-border text-muted-foreground hover:text-foreground"
              }`}
              aria-label="English"
            >
              EN
            </button>
          </div>
        </div>

        <div className="grid gap-12 md:grid-cols-3">
          <div className="flex flex-col gap-4 md:col-span-2">
            {t.paragraphs.map((paragraph, index) => (
              <p
                key={index}
                className="text-base leading-relaxed text-muted-foreground"
              >
                {paragraph}
              </p>
            ))}
          </div>

          <div>
            <h3 className="mb-4 font-mono text-sm font-semibold text-primary">
              {t.skillsTitle}
            </h3>
            <ul className="grid grid-cols-1 gap-2">
              {t.skills.map((skill) => (
                <li
                  key={skill}
                  className="flex items-center gap-2 font-mono text-sm text-muted-foreground"
                >
                  <span className="text-primary">{">"}</span>
                  {skill}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  )
}
