import { ExternalLink } from "lucide-react"

interface Experience {
  company: string
  role: string
  period: string
  description: string
  technologies: string[]
  url?: string
}

const experiences: Experience[] = [
  {
    company: "Empresa Tech S.A.",
    role: "Desenvolvedor Full Stack",
    period: "Jan 2025 — Presente",
    description:
      "Desenvolvimento e manutenção de aplicações web em larga escala. Colaboração com equipes multidisciplinares de designers, product managers e outros desenvolvedores para implementar novas funcionalidades e melhorar a performance.",
    technologies: ["React", "TypeScript", "Node.js", "PostgreSQL"],
    url: "https://example.com",
  },
  {
    company: "Startup Inovação",
    role: "Desenvolvedor Front-End (Estágio)",
    period: "Jun 2024 — Dez 2024",
    description:
      "Construção de interfaces responsivas e acessíveis utilizando React e Tailwind CSS. Participação em code reviews e implementação de testes automatizados para garantir a qualidade do código.",
    technologies: ["React", "Tailwind CSS", "Jest", "Git"],
    url: "https://example.com",
  },
  {
    company: "Freelancer",
    role: "Desenvolvedor Web",
    period: "Jan 2023 — Mai 2024",
    description:
      "Desenvolvimento de sites e landing pages para clientes diversos. Criação de soluções personalizadas com foco em performance, SEO e experiência do usuário.",
    technologies: ["Next.js", "WordPress", "CSS", "JavaScript"],
  },
  {
    company: "Projeto Open Source",
    role: "Contribuidor",
    period: "2022 — Presente",
    description:
      "Contribuições ativas em projetos de código aberto na comunidade JavaScript e TypeScript. Implementação de novas funcionalidades, correção de bugs e revisão de pull requests.",
    technologies: ["TypeScript", "React", "Node.js", "GitHub"],
  },
]

export function Experiences() {
  return (
    <section id="experiencias" className="px-6 py-24">
      <div className="mx-auto max-w-4xl">
        <div className="mb-12 flex items-center gap-4">
          <h2 className="text-2xl font-bold text-foreground md:text-3xl">
            Experiências
          </h2>
          <div className="h-px flex-1 bg-border" />
        </div>

        <div className="flex flex-col gap-6">
          {experiences.map((exp) => (
            <div
              key={`${exp.company}-${exp.role}`}
              className="group grid gap-4 rounded-lg border border-transparent p-6 transition-all hover:border-border hover:bg-card md:grid-cols-[200px_1fr]"
            >
              <div className="pt-1">
                <p className="font-mono text-xs uppercase tracking-wider text-muted-foreground">
                  {exp.period}
                </p>
              </div>

              <div>
                <h3 className="mb-1 flex items-center gap-2 text-lg font-semibold text-foreground">
                  {exp.role}
                  <span className="text-primary">·</span>
                  {exp.url ? (
                    <a
                      href={exp.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-primary transition-colors hover:underline"
                    >
                      {exp.company}
                      <ExternalLink className="h-3.5 w-3.5" />
                    </a>
                  ) : (
                    <span className="text-primary">{exp.company}</span>
                  )}
                </h3>
                <p className="mb-4 text-sm leading-relaxed text-muted-foreground">
                  {exp.description}
                </p>
                <div className="flex flex-wrap gap-2">
                  {exp.technologies.map((tech) => (
                    <span
                      key={tech}
                      className="rounded-full bg-primary/10 px-3 py-1 font-mono text-xs text-primary"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
