import { ExternalLink, Github } from "lucide-react"

interface Project {
  year: string
  title: string
  description: string
  technologies: string[]
  githubUrl: string
  liveUrl?: string
  image: string
}

const projects: Project[] = [
  {
    year: "2022",
    title: "Sistema de Gestão Escolar",
    description:
      "Plataforma completa para gerenciamento escolar com módulos de alunos, professores, turmas e notas. Interface intuitiva e responsiva com painel administrativo.",
    technologies: ["React", "Node.js", "PostgreSQL", "Express"],
    githubUrl: "https://github.com",
    image: "/placeholder.svg?height=300&width=500",
  },
  {
    year: "2023",
    title: "E-Commerce API",
    description:
      "API RESTful para e-commerce com autenticação JWT, carrinho de compras, processamento de pagamentos e gerenciamento de inventário.",
    technologies: ["Node.js", "TypeScript", "MongoDB", "Docker"],
    githubUrl: "https://github.com",
    image: "/placeholder.svg?height=300&width=500",
  },
  {
    year: "2024",
    title: "Dashboard de Analytics",
    description:
      "Dashboard interativo com visualização de dados em tempo real, gráficos dinâmicos e exportação de relatórios. Integração com múltiplas fontes de dados.",
    technologies: ["Next.js", "TypeScript", "Tailwind CSS", "Recharts"],
    githubUrl: "https://github.com",
    liveUrl: "https://example.com",
    image: "/placeholder.svg?height=300&width=500",
  },
  {
    year: "2025",
    title: "App de Gestão Financeira",
    description:
      "Aplicação web para controle financeiro pessoal com categorização automática de gastos, gráficos interativos e metas de economia.",
    technologies: ["Next.js", "Python", "FastAPI", "PostgreSQL"],
    githubUrl: "https://github.com",
    liveUrl: "https://example.com",
    image: "/placeholder.svg?height=300&width=500",
  },
]

export function Projects() {
  return (
    <section id="projetos" className="px-6 py-24">
      <div className="mx-auto max-w-4xl">
        <div className="mb-12 flex items-center gap-4">
          <h2 className="text-2xl font-bold text-foreground md:text-3xl">
            Projetos
          </h2>
          <div className="h-px flex-1 bg-border" />
        </div>

        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-4 top-0 h-full w-px bg-border md:left-1/2 md:-translate-x-px" />

          <div className="flex flex-col gap-16">
            {projects.map((project, index) => (
              <div
                key={project.title}
                className={`relative flex flex-col gap-6 pl-12 md:flex-row md:gap-12 md:pl-0 ${
                  index % 2 === 0 ? "md:flex-row-reverse" : ""
                }`}
              >
                {/* Timeline dot */}
                <div className="absolute left-2.5 top-1 h-3 w-3 rounded-full border-2 border-primary bg-background md:left-1/2 md:-translate-x-1/2" />

                {/* Year label */}
                <div
                  className={`absolute left-12 top-0 font-mono text-xs text-primary md:static md:flex md:w-1/2 md:items-start md:pt-1 ${
                    index % 2 === 0 ? "md:justify-start" : "md:justify-end"
                  }`}
                >
                  <span className="rounded-md bg-primary/10 px-3 py-1 font-mono text-xs font-semibold text-primary">
                    {project.year}
                  </span>
                </div>

                {/* Project card */}
                <div className="mt-6 md:mt-0 md:w-1/2">
                  <div className="group rounded-lg border border-border bg-card p-6 transition-all hover:border-primary/50 hover:bg-card/80">
                    <div className="mb-4 overflow-hidden rounded-md">
                      <img
                        src={project.image}
                        alt={`Screenshot do projeto ${project.title}`}
                        className="h-40 w-full object-cover transition-transform duration-300 group-hover:scale-105"
                      />
                    </div>

                    <h3 className="mb-2 text-lg font-bold text-foreground">
                      {project.title}
                    </h3>
                    <p className="mb-4 text-sm leading-relaxed text-muted-foreground">
                      {project.description}
                    </p>

                    <div className="mb-4 flex flex-wrap gap-2">
                      {project.technologies.map((tech) => (
                        <span
                          key={tech}
                          className="rounded-full bg-primary/10 px-3 py-1 font-mono text-xs text-primary"
                        >
                          {tech}
                        </span>
                      ))}
                    </div>

                    <div className="flex items-center gap-4">
                      <a
                        href={project.githubUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-muted-foreground transition-colors hover:text-primary"
                        aria-label={`Ver código de ${project.title} no GitHub`}
                      >
                        <Github className="h-5 w-5" />
                      </a>
                      {project.liveUrl && (
                        <a
                          href={project.liveUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-muted-foreground transition-colors hover:text-primary"
                          aria-label={`Ver ${project.title} ao vivo`}
                        >
                          <ExternalLink className="h-5 w-5" />
                        </a>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
